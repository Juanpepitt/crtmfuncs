def imprime():
    print("Imprimiendo la función imprime")